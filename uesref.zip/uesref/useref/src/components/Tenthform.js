import React, { useRef } from 'react'

function Tenthform() {

       let engInputRef=useRef();  
       let telInputRef=useRef(); 
       let hindiInputRef=useRef(); 
       let matInputRef=useRef(); 
       let sciInputRef=useRef(); 
       let socInputRef=useRef(); 


  return (
    <div className='mainDiv'>
      <form className='form'>
        <div>
            <label> First Name :</label>
            <input type='text'></input>
        </div>
        <div>
            <label> Last Name :</label>
            <input type='text'></input>
        </div>
        <div>
            <label> English :</label>
            <input ref={engInputRef}type="number"></input>
        </div>
        <div>
            <label> Telugu :</label>
            <input ref={telInputRef}type="number"></input>
        </div>
        <div>
            <label> Hindi :</label>
            <input ref={hindiInputRef} type="number"></input>
        </div>
        <div>
            <label> Maths :</label>
            <input ref={matInputRef} type="number"></input>
        </div>
        <div>
            <label> Science :</label>
            <input ref={sciInputRef} type="number"></input>
        </div>
        <div>
            <label> Social:</label>
            <input ref={socInputRef} type='number'></input>
        </div>
        
        <button  className='button' type="button" onClick={()=>{
           let engMarks= Number(engInputRef.current.value);
           let telMarks= Number(telInputRef.current.value);
           let hindiMarks= Number(hindiInputRef.current.value);
           let matMarks= Number(matInputRef.current.value);
           let sciMarks= Number(sciInputRef.current.value);
           let socMarks= Number(socInputRef.current.value);


            let totalMarks=engMarks+telMarks+hindiMarks+matMarks+sciMarks+socMarks
        
        alert(totalMarks);



        }}>Total Marks</button>
    
      </form>
    </div>
  )
}

export default Tenthform
