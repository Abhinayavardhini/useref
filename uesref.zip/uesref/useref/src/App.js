import logo from './logo.svg';
import './App.css';
import Tenthform from './components/Tenthform';

function App() {
  return (
    <div className='App'>
      <Tenthform/>
    </div>
  );
}

export default App;
